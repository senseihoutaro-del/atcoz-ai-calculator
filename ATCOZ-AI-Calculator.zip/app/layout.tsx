import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ATCOZ AI Calculator",
  description: "Scientific calculator and business calculator for ATCOZ."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}