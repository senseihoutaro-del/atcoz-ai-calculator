import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { question } = await req.json();
  const key = process.env.OPENAI_API_KEY;
  if (!key) return NextResponse.json({ error: "OPENAI_API_KEY belum diatur di Vercel." }, { status: 500 });

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      input: [
        {
          role: "system",
          content: "Kamu adalah AI assistant kalkulator bisnis Indonesia untuk ATCOZ. Jawab bahasa Indonesia yang singkat, jelas, dan bantu hitung angka dengan teliti. Jika ada PPN, tampilkan subtotal, PPN, dan grand total. Jangan mengarang harga ATCOZ yang tidak diberikan pengguna."
        },
        { role: "user", content: String(question || "") }
      ]
    })
  });

  const data = await response.json();
  if (!response.ok) return NextResponse.json({ error: data?.error?.message || "AI request gagal." }, { status: response.status });
  const text = data.output_text || data.output?.flatMap((x:any)=>x.content||[]).map((x:any)=>x.text||"").join("") || "Tidak ada jawaban.";
  return NextResponse.json({ answer: text });
}