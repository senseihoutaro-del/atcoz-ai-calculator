# ATCOZ AI Calculator

## Jalankan di komputer
```bash
npm install
npm run dev
```
Buka http://localhost:3000

## Deploy ke Vercel
1. Upload project ini ke GitHub, lalu Import repository di Vercel.
2. Framework akan terdeteksi sebagai Next.js.
3. Tambahkan Environment Variable:
   - `OPENAI_API_KEY` = API key OpenAI kamu
   - `OPENAI_MODEL` = model yang tersedia di akunmu (opsional)
4. Deploy.

Tanpa OPENAI_API_KEY, kalkulator scientific dan kalkulator maklon tetap bisa digunakan; hanya fitur AI yang tidak aktif.

## Catatan
Versi ini sengaja memakai API key di server route `/api/ai`, bukan di browser, supaya key tidak terekspos ke pengunjung.
